---
title: 'Help & Support'
taxonomy:
    category:
        - docs
        - document-ninja
visible: true
---

* If you experience problems or script errors using our tools or files created by our tools, please log a job via our [helpdesk](https://help.coursesuite.ninja).
