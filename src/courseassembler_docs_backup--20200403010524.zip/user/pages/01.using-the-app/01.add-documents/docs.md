---
title: Add-documents
menu: 'Add your Documents'
redirect: usage/add-documents/uploading-documents
routable: false
---

