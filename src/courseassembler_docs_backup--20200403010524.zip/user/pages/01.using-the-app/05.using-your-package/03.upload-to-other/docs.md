---
title: 'Uploading a SCORM package for another LMS'
visible: true
---

... to do ...

This is only available to API users
