---
menu: 'Download your Package'
redirect: usage/publishing-your-package/metadata
routable: false
---

